'use strict';

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const DB_FILE = path.join(__dirname, 'attendalert.sqlite');
const SCHEMA_FILE = path.join(__dirname, 'schema.sql');
const SEED_FILE = path.join(__dirname, 'seed.sql');

// Native Node sqlite (Node 22.5+) with automatic fallback to system sqlite3 CLI / Python sqlite3 driver
// so real SQLite database files (.sqlite) work out-of-the-box with zero external npm installs.
let nodeSqlite = null;
try {
  nodeSqlite = require('node:sqlite');
} catch {
  nodeSqlite = null;
}

function runPythonSqlite(sqlScript, params = [], mode = 'exec') {
  const py = `
import json, sqlite3, sys
db_path = sys.argv[1]
mode = sys.argv[2]
sql = sys.argv[3]
params = json.loads(sys.argv[4])
conn = sqlite3.connect(db_path)
conn.row_factory = sqlite3.Row
conn.execute("PRAGMA foreign_keys = ON;")
cur = conn.cursor()
if mode == "script":
    cur.executescript(sql)
    conn.commit()
    print(json.dumps({"ok": True}))
elif mode == "all":
    cur.execute(sql, params)
    rows = [dict(r) for r in cur.fetchall()]
    print(json.dumps({"ok": True, "rows": rows}))
else:
    cur.execute(sql, params)
    conn.commit()
    print(json.dumps({"ok": True, "lastInsertRowid": cur.lastrowid, "changes": cur.rowcount}))
conn.close()
`;
  const out = execFileSync('python3', ['-c', py, DB_FILE, mode, sqlScript, JSON.stringify(params)], {
    encoding: 'utf8'
  });
  return JSON.parse(out.trim() || '{"ok":true}');
}

class SqliteDatabase {
  constructor() {
    this.driver = nodeSqlite ? 'node:sqlite' : 'sqlite3-native';
    if (nodeSqlite) {
      this.db = new nodeSqlite.DatabaseSync(DB_FILE);
      this.db.exec('PRAGMA foreign_keys = ON;');
    }
    this.initSchema();
  }

  initSchema() {
    const schemaSql = fs.readFileSync(SCHEMA_FILE, 'utf8');
    const seedSql = fs.readFileSync(SEED_FILE, 'utf8');
    this.execScript(schemaSql);
    this.execScript(seedSql);
  }

  execScript(sql) {
    if (this.db) {
      this.db.exec(sql);
      return;
    }
    runPythonSqlite(sql, [], 'script');
  }

  run(sql, params = []) {
    if (this.db) {
      const stmt = this.db.prepare(sql);
      return stmt.run(...params);
    }
    return runPythonSqlite(sql, params, 'run');
  }

  all(sql, params = []) {
    if (this.db) {
      const stmt = this.db.prepare(sql);
      return stmt.all(...params);
    }
    return runPythonSqlite(sql, params, 'all').rows || [];
  }

  get(sql, params = []) {
    const rows = this.all(sql, params);
    return rows[0] || null;
  }

  syncSnapshot(snap) {
    const upsertStudent = (s) => this.run(
      `INSERT INTO students (id, name, email, parent_email) VALUES (?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET name=excluded.name, email=excluded.email, parent_email=excluded.parent_email`,
      [s.id, s.name, s.email, s.parent || 'parent@college.edu']
    );
    for (const s of (snap.students || [])) {
      upsertStudent(s);
    }
    for (const sess of (snap.sessions || [])) {
      this.run(
        `INSERT OR IGNORE INTO attendance_sessions (id, subj_id, session_date) VALUES (?, ?, ?)`,
        [sess.id, sess.subj, sess.date]
      );
      const row = this.get(
        `SELECT id FROM attendance_sessions WHERE subj_id = ? AND session_date = ?`,
        [sess.subj, sess.date]
      );
      if (row && sess.marks) {
        for (const [sid, status] of Object.entries(sess.marks)) {
          this.run(
            `INSERT INTO attendance_records (session_id, student_id, status) VALUES (?, ?, ?)
             ON CONFLICT(session_id, student_id) DO UPDATE SET status=excluded.status`,
            [row.id, sid, status]
          );
        }
      }
    }
    for (const ex of (snap.exempt || [])) {
      const existing = this.get(
        `SELECT id FROM exemptions WHERE student_id = ? AND subj_id = ? AND certificate_name = ?`,
        [ex.sid, ex.subj, ex.file]
      );
      if (!existing) {
        this.run(
          `INSERT INTO exemptions (student_id, subj_id, days_excused, certificate_name) VALUES (?, ?, ?, ?)`,
          [ex.sid, ex.subj, Number(ex.n || 1), ex.file]
        );
      }
    }
    for (const note of (snap.interventions || [])) {
      const existing = this.get(
        `SELECT id FROM interventions WHERE student_id = ? AND note = ?`,
        [note.sid, note.note]
      );
      if (!existing) {
        this.run(
          `INSERT INTO interventions (student_id, note, created_at) VALUES (?, ?, ?)`,
          [note.sid, note.note, note.at || new Date().toISOString()]
        );
      }
    }
  }
}

module.exports = { SqliteDatabase, DB_FILE };
