'use strict';

const crypto = require('crypto');

function logStructured(level, event, meta = {}) {
  const entry = {
    ts: new Date().toISOString(),
    level,
    service: 'attendalert-api',
    event,
    ...meta
  };
  process.stdout.write(JSON.stringify(entry) + '\n');
  return entry;
}

function attachRequestContext(req, res) {
  const requestId = req.headers['x-request-id'] || crypto.randomUUID();
  const start = process.hrtime.bigint();
  res.setHeader('X-Request-Id', requestId);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type,Authorization,X-Request-Id');

  res.on('finish', () => {
    const durationMs = Number(process.hrtime.bigint() - start) / 1e6;
    logStructured('INFO', 'http_request', {
      requestId,
      method: req.method,
      path: req.url,
      status: res.statusCode,
      durationMs: Number(durationMs.toFixed(2))
    });
  });

  return requestId;
}

function sendJson(res, status, payload) {
  if (res.writableEnded) return;
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(payload));
}

function parseJsonBody(req, maxBytes = 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    let raw = '';
    req.on('data', chunk => {
      size += chunk.length;
      if (size > maxBytes) {
        const err = new Error('Payload too large');
        err.status = 413;
        reject(err);
        req.destroy();
        return;
      }
      raw += chunk;
    });
    req.on('end', () => {
      if (!raw) return resolve({});
      try {
        resolve(JSON.parse(raw));
      } catch {
        const err = new Error('Malformed JSON payload');
        err.status = 400;
        reject(err);
      }
    });
    req.on('error', reject);
  });
}

function validateLoginPayload(body) {
  if (!body || typeof body !== 'object') return 'Request body must be a JSON object';
  const email = String(body.email || '').trim();
  const password = String(body.password || '');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return 'Valid email address is required';
  if (password.length < 6 || password.length > 128) return 'Password must be between 6 and 128 characters';
  return null;
}

function validateSessionPayload(body) {
  if (!body || typeof body !== 'object') return 'Request body must be a JSON object';
  if (!/^[A-Z]{2,6}$/.test(String(body.subjId || ''))) return 'Invalid subject ID';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(body.date || ''))) return 'Date must be YYYY-MM-DD';
  if (!body.marks || typeof body.marks !== 'object' || Array.isArray(body.marks)) {
    return 'marks map is required';
  }
  for (const [sid, status] of Object.entries(body.marks)) {
    if (!/^S\d{2,4}$/.test(sid)) return `Invalid student ID: ${sid}`;
    if (!['P', 'A', 'L'].includes(status)) return `Invalid attendance status for ${sid}`;
  }
  return null;
}

function withErrorBoundary(handler) {
  return async (req, res) => {
    const requestId = attachRequestContext(req, res);
    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      return res.end();
    }
    try {
      await handler(req, res, requestId);
    } catch (err) {
      const status = err.status || 500;
      logStructured('ERROR', 'unhandled_api_error', {
        requestId,
        method: req.method,
        path: req.url,
        status,
        message: err.message
      });
      sendJson(res, status, {
        ok: false,
        requestId,
        error: status === 500 ? 'Internal server error' : err.message
      });
    }
  };
}

module.exports = {
  logStructured,
  sendJson,
  parseJsonBody,
  validateLoginPayload,
  validateSessionPayload,
  withErrorBoundary
};
