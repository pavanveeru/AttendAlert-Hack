'use strict';

const OPENAPI_SPEC = {
  openapi: '3.0.3',
  info: {
    title: 'AttendAlert Early-Warning Attendance API',
    version: '2.1.0',
    description: 'RESTful API backed by SQLite for attendance logging, 75% threshold recovery forecasting, risk classification, and audit telemetry.'
  },
  servers: [{ url: 'http://localhost:4000', description: 'Local Development Server' }],
  paths: {
    '/api/health': {
      get: {
        summary: 'Service health & SQLite database check',
        responses: { '200': { description: 'Healthy service status' } }
      }
    },
    '/api/auth/login': {
      post: {
        summary: 'Authenticate mentor or student with PBKDF2-verified credentials',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['email', 'password'],
                properties: {
                  email: { type: 'string', format: 'email', example: 'mentor@college.edu' },
                  password: { type: 'string', example: 'mentor@123' }
                }
              }
            }
          }
        },
        responses: {
          '200': { description: 'Authenticated user session' },
          '400': { description: 'Validation error' },
          '401': { description: 'Invalid credentials' }
        }
      }
    },
    '/api/sessions': {
      post: {
        summary: 'Record an attendance session directly into SQLite',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['subjId', 'date', 'marks'],
                properties: {
                  subjId: { type: 'string', example: 'DS' },
                  date: { type: 'string', format: 'date', example: '2026-11-20' },
                  marks: { type: 'object', additionalProperties: { type: 'string', enum: ['P', 'A', 'L'] } }
                }
              }
            }
          }
        },
        responses: {
          '201': { description: 'Session persisted in SQLite' },
          '400': { description: 'Validation failed' },
          '409': { description: 'Duplicate subject + date session' }
        }
      }
    },
    '/api/sync': {
      post: {
        summary: 'Synchronize full client snapshot into SQLite relational tables',
        responses: { '200': { description: 'Snapshot synchronized' } }
      }
    },
    '/api/analytics/summary': {
      get: {
        summary: 'Compute live attendance percentages, risk tiers, and 75% recovery targets from SQLite',
        responses: { '200': { description: 'Student risk & recovery summary' } }
      }
    },
    '/api/openapi.json': {
      get: {
        summary: 'Download OpenAPI 3.0 JSON specification',
        responses: { '200': { description: 'OpenAPI JSON document' } }
      }
    }
  }
};

function renderDocsHtml() {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>AttendAlert — Live API Documentation</title>
  <style>
    body { font-family: system-ui, sans-serif; background: #1E0F13; color: #FFF7F2; margin: 0; padding: 32px; }
    .wrap { max-width: 900px; margin: auto; }
    h1 { color: #F39E60; margin-bottom: 6px; }
    .sub { color: #DFC3BA; margin-bottom: 24px; }
    .card { background: #2B151B; border: 1px solid rgba(243,158,96,0.28); border-radius: 12px; padding: 18px 20px; margin-bottom: 14px; }
    .method { display: inline-block; padding: 3px 9px; border-radius: 6px; font-weight: 700; font-size: 0.78rem; margin-right: 10px; }
    .GET { background: #F39E60; color: #210C10; }
    .POST { background: #E16A54; color: #FFFDFB; }
    code { color: #F39E60; }
    a { color: #F39E60; }
  </style>
</head>
<body>
  <div class="wrap">
    <h1>AttendAlert REST API Documentation (v2.1.0)</h1>
    <p class="sub">SQLite-backed attendance analytics &amp; early-warning service · <a href="/api/openapi.json">OpenAPI 3.0 JSON</a></p>
    ${Object.entries(OPENAPI_SPEC.paths).map(([route, methods]) =>
      Object.entries(methods).map(([m, info]) => `
        <div class="card">
          <span class="method ${m.toUpperCase()}">${m.toUpperCase()}</span>
          <code>${route}</code>
          <p>${info.summary}</p>
        </div>
      `).join('')
    ).join('')}
  </div>
</body>
</html>`;
}

module.exports = { OPENAPI_SPEC, renderDocsHtml };
