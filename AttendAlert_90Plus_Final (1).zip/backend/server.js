'use strict';

const http = require('http');
const crypto = require('crypto');
const { SqliteDatabase } = require('./db');
const {
  logStructured,
  sendJson,
  parseJsonBody,
  validateLoginPayload,
  validateSessionPayload,
  withErrorBoundary
} = require('./middleware');
const { OPENAPI_SPEC, renderDocsHtml } = require('./openapi');

const PORT = Number(process.env.PORT || 4000);
const db = new SqliteDatabase();

function hashPassword(password, salt) {
  return crypto.pbkdf2Sync(String(password), String(salt), 100000, 64, 'sha256').toString('hex');
}

function ensureDefaultUsers() {
  const mentorSalt = 'aa-mentor-salt-2026';
  const studentSalt = 'aa-student-salt-2026';
  db.run(
    `INSERT OR IGNORE INTO users (id, email, role, name, password_hash, salt) VALUES (?, ?, ?, ?, ?, ?)`,
    ['mentor', 'mentor@college.edu', 'mentor', 'Dr. Mentor', hashPassword('mentor@123', mentorSalt), mentorSalt]
  );
  db.run(
    `INSERT OR IGNORE INTO users (id, email, role, name, password_hash, salt) VALUES (?, ?, ?, ?, ?, ?)`,
    ['S01', 's01@college.edu', 'student', 'Rahul Verma', hashPassword('student@123', studentSalt), studentSalt]
  );
}
ensureDefaultUsers();

function classifyTier(pct) {
  if (pct >= 75) return 'safe';
  if (pct >= 65) return 'warning';
  return 'critical';
}

function classesNeeded(attended, total) {
  if (total <= 0 || (attended / total) * 100 >= 75) return 0;
  return Math.max(0, Math.ceil((0.75 * total - attended) / 0.25));
}

const server = http.createServer(withErrorBoundary(async (req, res, requestId) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);

  if (req.method === 'GET' && url.pathname === '/api/health') {
    const counts = db.get(`SELECT COUNT(*) AS students FROM students`);
    return sendJson(res, 200, {
      ok: true,
      service: 'AttendAlert API',
      database: db.driver,
      studentsCount: counts ? counts.students : 0,
      timestamp: new Date().toISOString()
    });
  }

  if (req.method === 'GET' && url.pathname === '/api/openapi.json') {
    return sendJson(res, 200, OPENAPI_SPEC);
  }

  if (req.method === 'GET' && url.pathname === '/api/docs') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    return res.end(renderDocsHtml());
  }

  if (req.method === 'POST' && url.pathname === '/api/auth/login') {
    const body = await parseJsonBody(req);
    const validationError = validateLoginPayload(body);
    if (validationError) {
      return sendJson(res, 400, { ok: false, error: validationError });
    }
    const email = body.email.trim().toLowerCase();
    const user = db.get(`SELECT id, email, role, name, password_hash, salt FROM users WHERE LOWER(email) = ?`, [email]);
    if (!user || hashPassword(body.password, user.salt) !== user.password_hash) {
      logStructured('WARN', 'auth_failed', { requestId, email });
      return sendJson(res, 401, { ok: false, error: 'Invalid credentials' });
    }
    db.run(`INSERT INTO audit_logs (actor, action, detail) VALUES (?, ?, ?)`, [
      `${user.id} (${user.role})`,
      'API_LOGIN',
      `Authenticated ${user.email}`
    ]);
    return sendJson(res, 200, {
      ok: true,
      user: { id: user.id, email: user.email, role: user.role, name: user.name }
    });
  }

  if (req.method === 'POST' && url.pathname === '/api/sessions') {
    const body = await parseJsonBody(req);
    const validationError = validateSessionPayload(body);
    if (validationError) {
      return sendJson(res, 400, { ok: false, error: validationError });
    }
    const dup = db.get(`SELECT id FROM attendance_sessions WHERE subj_id = ? AND session_date = ?`, [body.subjId, body.date]);
    if (dup) {
      return sendJson(res, 409, { ok: false, error: 'Session already recorded for this subject and date' });
    }
    const inserted = db.run(`INSERT INTO attendance_sessions (subj_id, session_date) VALUES (?, ?)`, [body.subjId, body.date]);
    const sessionRow = db.get(`SELECT id FROM attendance_sessions WHERE subj_id = ? AND session_date = ?`, [body.subjId, body.date]);
    for (const [sid, status] of Object.entries(body.marks)) {
      db.run(`INSERT INTO attendance_records (session_id, student_id, status) VALUES (?, ?, ?)`, [sessionRow.id, sid, status]);
    }
    db.run(`INSERT INTO audit_logs (actor, action, detail) VALUES (?, ?, ?)`, [
      'mentor',
      'SESSION_RECORDED',
      `${body.subjId} on ${body.date}`
    ]);
    return sendJson(res, 201, { ok: true, sessionId: sessionRow.id || inserted.lastInsertRowid });
  }

  if (req.method === 'POST' && url.pathname === '/api/sync') {
    const snap = await parseJsonBody(req, 5 * 1024 * 1024);
    if (!Array.isArray(snap.students) || !Array.isArray(snap.sessions)) {
      return sendJson(res, 400, { ok: false, error: 'Snapshot must include students and sessions arrays' });
    }
    db.syncSnapshot(snap);
    return sendJson(res, 200, { ok: true, syncedStudents: snap.students.length, syncedSessions: snap.sessions.length });
  }

  if (req.method === 'GET' && url.pathname === '/api/analytics/summary') {
    const students = db.all(`SELECT id, name, email FROM students ORDER BY id ASC`);
    const summary = students.map(s => {
      const counts = db.get(
        `SELECT
           COUNT(*) AS held,
           COALESCE(SUM(CASE WHEN status != 'A' THEN 1 ELSE 0 END), 0) AS attended
         FROM attendance_records WHERE student_id = ?`,
        [s.id]
      );
      const ex = db.get(`SELECT COALESCE(SUM(days_excused), 0) AS excused FROM exemptions WHERE student_id = ?`, [s.id]);
      const held = Number(counts?.held || 0);
      const attended = Math.min(held, Number(counts?.attended || 0) + Number(ex?.excused || 0));
      const pct = held > 0 ? (attended / held) * 100 : 100;
      return {
        id: s.id,
        name: s.name,
        attended,
        held,
        pct: Number(pct.toFixed(1)),
        tier: classifyTier(pct),
        need: classesNeeded(attended, held)
      };
    });
    return sendJson(res, 200, { ok: true, database: db.driver, students: summary });
  }

  return sendJson(res, 404, { ok: false, error: 'Endpoint not found' });
}));

if (require.main === module) {
  server.listen(PORT, () => {
    logStructured('INFO', 'server_started', { port: PORT, database: db.driver, docsUrl: `http://localhost:${PORT}/api/docs` });
  });
}

module.exports = { server, db, classifyTier, classesNeeded, hashPassword };
