INSERT OR IGNORE INTO subjects (id, name) VALUES
  ('DS', 'Data Structures'),
  ('DBMS', 'DBMS'),
  ('OS', 'Operating Systems'),
  ('CN', 'Computer Networks'),
  ('DM', 'Discrete Maths');

INSERT OR IGNORE INTO users (id, email, role, name, password_hash, salt) VALUES
  ('mentor', 'mentor@college.edu', 'mentor', 'Dr. Mentor', 'seeded_mentor_hash', 'aa_salt_v1');
