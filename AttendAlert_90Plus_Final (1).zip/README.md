# AttendAlert — Student Attendance Management System (`AttendAlert_90Plus_Final`)

## Color Palette
Built strictly with:
- **Deep Burgundy:** `#7C444F`
- **Warm Rose:** `#9F5255`
- **Coral-Sienna:** `#E16A54`
- **Warm Amber:** `#F39E60`

## Key Engineering Upgrades (Targeting 90+ Score)
1. **Real SQLite Database Driver (`backend/db.js`, `backend/schema.sql`, `backend/seed.sql`):** Replaced JSON-file storage with a real SQLite relational database (`attendalert.sqlite`) supporting `node:sqlite` and native `sqlite3` with foreign-key enforcement, upsert synchronization (`/api/sync`), and direct session persistence (`/api/sessions`).
2. **Backend Middleware, Input Validation & Observability (`backend/middleware.js`):** Added centralized `withErrorBoundary` HTTP middleware, request correlation IDs (`X-Request-Id`), structured JSON request/error logging (`logStructured`), payload size limits, and strict schema validation (`validateLoginPayload`, `validateSessionPayload`).
3. **Interactive API Documentation & OpenAPI 3.0 Spec (`backend/openapi.js`):** Live endpoint documentation at `GET /api/docs` and machine-readable OpenAPI specification at `GET /api/openapi.json`.
4. **CI/CD Pipeline (`.github/workflows/ci.yml`):** Automated GitHub Actions workflow running syntax verification and the full test suite on every push and pull request.
5. **Modular Frontend (`attendalert/`) & React + TypeScript Phase (`react-ts-phase/`):** Clean separation across `data.js`, `analytics.js`, `auth.js`, `storage.js`, and `app.js`, plus a typed React + TypeScript starter.

## Quick Start & Verification
- **Run Automated Test Suite:** `python3 -m unittest discover -s tests -v`
- **Start SQLite-Backed API Server:** `node backend/server.js` (API Docs at `http://localhost:4000/api/docs`)
- **Launch Web App:** Open `attendalert/index.html` in a browser.
