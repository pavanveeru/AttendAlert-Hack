export type AttendanceStatus = 'P' | 'A' | 'L';
export type RiskTier = 'safe' | 'warning' | 'critical';
export type UserRole = 'mentor' | 'student';

export interface Subject {
  id: string;
  name: string;
}

export interface Student {
  id: string;
  name: string;
  email: string;
  parentEmail: string;
}

export interface AttendanceSession {
  id: number;
  subjId: string;
  date: string;
  marks: Record<string, AttendanceStatus>;
}

export interface MedicalExemption {
  id: number;
  studentId: string;
  subjId: string;
  daysExcused: number;
  certificateName: string;
}

export interface AttendanceSummary {
  attended: number;
  held: number;
  percentage: number;
  tier: RiskTier;
  classesNeeded: number;
}
