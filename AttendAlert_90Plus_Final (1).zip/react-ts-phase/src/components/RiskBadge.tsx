import React from 'react';
import { RiskTier } from '../types/attendance';

interface RiskBadgeProps {
  tier: RiskTier;
}

const PALETTE_STYLES: Record<RiskTier, React.CSSProperties> = {
  safe: {
    backgroundColor: 'rgba(243, 158, 96, 0.22)',
    color: '#F39E60',
    border: '1px solid #F39E60'
  },
  warning: {
    backgroundColor: 'rgba(225, 106, 84, 0.24)',
    color: '#E16A54',
    border: '1px solid #E16A54'
  },
  critical: {
    backgroundColor: 'rgba(159, 82, 85, 0.38)',
    color: '#FFF7F2',
    border: '1px solid #9F5255'
  }
};

export const RiskBadge: React.FC<RiskBadgeProps> = ({ tier }) => {
  const label = tier.charAt(0).toUpperCase() + tier.slice(1);
  return (
    <span
      style={{
        ...PALETTE_STYLES[tier],
        padding: '3px 10px',
        borderRadius: '999px',
        fontSize: '0.75rem',
        fontWeight: 700,
        display: 'inline-block'
      }}
    >
      {label}
    </span>
  );
};
