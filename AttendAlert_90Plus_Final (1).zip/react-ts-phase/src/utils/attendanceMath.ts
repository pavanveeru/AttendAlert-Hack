import { RiskTier, AttendanceSummary } from '../types/attendance';

export const ATTENDANCE_THRESHOLD = 0.75;

export function classifyRiskTier(percentage: number): RiskTier {
  if (percentage >= 75) return 'safe';
  if (percentage >= 65) return 'warning';
  return 'critical';
}

export function calculateRecoveryClasses(
  attended: number,
  totalHeld: number,
  threshold: number = ATTENDANCE_THRESHOLD
): number {
  if (totalHeld <= 0) return 0;
  const pct = (attended / totalHeld) * 100;
  if (pct >= threshold * 100) return 0;
  return Math.max(0, Math.ceil((threshold * totalHeld - attended) / (1 - threshold)));
}

export function buildAttendanceSummary(attended: number, totalHeld: number): AttendanceSummary {
  const percentage = totalHeld > 0 ? (attended / totalHeld) * 100 : 100;
  return {
    attended,
    held: totalHeld,
    percentage,
    tier: classifyRiskTier(percentage),
    classesNeeded: calculateRecoveryClasses(attended, totalHeld)
  };
}
