import React from 'react';
import { RiskBadge } from './components/RiskBadge';
import { buildAttendanceSummary } from './utils/attendanceMath';

export const App: React.FC = () => {
  // Example edge case from brief: 10 attended out of 16 held = 62.5% -> needs 8 straight classes
  const sample = buildAttendanceSummary(10, 16);

  return (
    <div style={{ backgroundColor: '#241116', color: '#FFF7F2', minHeight: '100vh', padding: '2rem', fontFamily: 'Manrope, sans-serif' }}>
      <header style={{ borderBottom: '1px solid rgba(243,158,96,0.25)', paddingBottom: '1rem', marginBottom: '1.5rem' }}>
        <h1 style={{ color: '#F39E60', margin: 0 }}>AttendAlert — React + TypeScript Phase</h1>
        <p style={{ color: '#DFC3BA', marginTop: '0.35rem' }}>
          Palette: #7C444F · #9F5255 · #E16A54 · #F39E60
        </p>
      </header>
      <section style={{ background: 'linear-gradient(155deg, rgba(124,68,79,0.38), rgba(43,21,27,0.9))', border: '1px solid rgba(243,158,96,0.2)', borderRadius: '14px', padding: '1.5rem', maxWidth: '520px' }}>
        <h2 style={{ marginTop: 0 }}>Sample Recovery Projection (Rahul Verma · DS)</h2>
        <p>Attended / Held: <strong>{sample.attended} / {sample.held}</strong> ({sample.percentage.toFixed(1)}%)</p>
        <p>Risk Tier: <RiskBadge tier={sample.tier} /></p>
        <p>Consecutive Classes Needed for 75%: <strong style={{ color: '#F39E60' }}>{sample.classesNeeded}</strong></p>
      </section>
    </div>
  );
};

export default App;
