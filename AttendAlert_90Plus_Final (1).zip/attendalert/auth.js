'use strict';

const SESSION_KEY = 'aa.s';
const SESSION_TTL = 30 * 60 * 1000;
const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_MS = 60 * 1000;

async function sha(text) {
  try {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('aa$' + text));
    return [...new Uint8Array(buf)].map(x => x.toString(16).padStart(2, '0')).join('');
  } catch {
    let h = 5381;
    for (const c of 'aa$' + text) {
      h = ((h * 33) ^ c.charCodeAt(0)) >>> 0;
    }
    return 'f' + h;
  }
}

const AuthService = (() => {
  let fails = 0;
  let lockUntil = 0;

  function getSession(users) {
    try {
      const raw = sessionStorage.getItem(SESSION_KEY);
      if (!raw) return null;
      const sess = JSON.parse(raw);
      if (
        sess &&
        typeof sess.id === 'string' &&
        typeof sess.role === 'string' &&
        sess.exp > Date.now() &&
        Array.isArray(users) &&
        users.some(u => u.id === sess.id && u.role === sess.role)
      ) {
        return sess;
      }
    } catch {
      // Ignore malformed session payload and clear
    }
    sessionStorage.removeItem(SESSION_KEY);
    return null;
  }

  function createSession(user) {
    const payload = { id: user.id, role: user.role, exp: Date.now() + SESSION_TTL };
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(payload));
    return payload;
  }

  function clearSession() {
    sessionStorage.removeItem(SESSION_KEY);
  }

  async function authenticate(users, email, password) {
    if (Date.now() < lockUntil) {
      const secs = Math.ceil((lockUntil - Date.now()) / 1000);
      return { ok: false, message: `Too many attempts. Try again in ${secs}s.` };
    }
    const cleanEmail = String(email || '').trim().toLowerCase();
    if (!cleanEmail || !password) {
      return { ok: false, message: 'Enter your email and password.' };
    }
    if (!Array.isArray(users) || users.length === 0) {
      return { ok: false, message: 'Still loading — try again in a second.' };
    }
    const user = users.find(u => u.email.toLowerCase() === cleanEmail);
    if (!user) {
      return { ok: false, message: 'No account found for that email. Use a demo button below.' };
    }
    const digest = await sha(password);
    if (user.hash !== digest) {
      fails += 1;
      if (fails >= MAX_LOGIN_ATTEMPTS) {
        lockUntil = Date.now() + LOCKOUT_MS;
        fails = 0;
        return { ok: false, message: 'Too many attempts. Locked for 60 seconds.' };
      }
      return { ok: false, message: `Wrong password (${MAX_LOGIN_ATTEMPTS - fails} attempts left).` };
    }
    fails = 0;
    lockUntil = 0;
    const session = createSession(user);
    return { ok: true, user, session };
  }

  function isRouteAllowed(role, route, navMap) {
    const allowed = navMap[role] || [];
    return allowed.some(item => item[0] === route);
  }

  return {
    getSession,
    createSession,
    clearSession,
    authenticate,
    isRouteAllowed
  };
})();
