'use strict';

const AttendanceAnalytics = (() => {
  const THRESHOLD = 0.75;

  function classifyTier(pct) {
    if (pct >= 75) return 'safe';
    if (pct >= 65) return 'warning';
    return 'critical';
  }

  // Closed-form recovery formula: ceil((0.75 * total - attended) / 0.25)
  function classesNeededForRecovery(attended, total, targetRatio = THRESHOLD) {
    if (total <= 0) return 0;
    const pct = (attended / total) * 100;
    if (pct >= targetRatio * 100) return 0;
    const denom = 1 - targetRatio;
    return Math.max(0, Math.ceil((targetRatio * total - attended) / denom));
  }

  function buildIndex(db, subjects = SUBJECTS) {
    const idx = {};
    for (const s of db.students) {
      idx[s.id] = {};
      for (const u of subjects) {
        idx[s.id][u.id] = { a: 0, t: 0 };
      }
    }
    for (const x of db.sessions) {
      for (const id in x.marks) {
        const cell = idx[id]?.[x.subj];
        if (!cell) continue;
        cell.t += 1;
        if (x.marks[id] !== 'A') cell.a += 1;
      }
    }
    for (const e of (db.exempt || [])) {
      const cell = idx[e.sid]?.[e.subj];
      if (cell) {
        cell.a = Math.min(cell.t, cell.a + Number(e.n || 0));
      }
    }
    return idx;
  }

  function computeStats(idx, studentId, subjId = null) {
    const studentIdx = idx[studentId];
    if (!studentIdx) return { a: 0, t: 0, p: 100, tier: 'safe', need: 0 };

    const cell = subjId
      ? (studentIdx[subjId] || { a: 0, t: 0 })
      : Object.values(studentIdx).reduce((acc, x) => ({ a: acc.a + x.a, t: acc.t + x.t }), { a: 0, t: 0 });

    const pct = cell.t ? (cell.a / cell.t) * 100 : 100;
    return {
      a: cell.a,
      t: cell.t,
      p: pct,
      tier: classifyTier(pct),
      need: classesNeededForRecovery(cell.a, cell.t)
    };
  }

  function pearsonCorrelation(points) {
    const n = points.length;
    if (n < 2) return 0;
    const mx = points.reduce((acc, pt) => acc + pt.x, 0) / n;
    const my = points.reduce((acc, pt) => acc + pt.y, 0) / n;
    let num = 0, denX = 0, denY = 0;
    for (const pt of points) {
      const dx = pt.x - mx;
      const dy = pt.y - my;
      num += dx * dy;
      denX += dx * dx;
      denY += dy * dy;
    }
    return denX && denY ? num / Math.sqrt(denX * denY) : 0;
  }

  function sanitizeCsvCell(val) {
    const str = String(val ?? '');
    const neutralized = /^[=+\-@]/.test(str) ? "'" + str : str;
    return `"${neutralized.replace(/"/g, '""')}"`;
  }

  function parseCsvRows(rawText, students, subjects) {
    const validStudentIds = new Set(students.map(s => s.id));
    const validSubjIds = new Set(subjects.map(u => u.id));
    const lines = String(rawText || '').split(/\r?\n/).filter(Boolean);
    const badRows = [];
    const grouped = {};

    lines.forEach((line, idx) => {
      if (idx === 0 && /roll/i.test(line)) return;
      const parts = line.split(',').map(x => x.trim());
      if (parts.length < 4) {
        badRows.push(idx + 1);
        return;
      }
      const [roll, subj, date, statusRaw] = parts;
      const status = (statusRaw || '').toUpperCase();
      if (
        !validStudentIds.has(roll) ||
        !validSubjIds.has(subj) ||
        !/^\d{4}-\d{2}-\d{2}$/.test(date) ||
        !['P', 'A', 'L'].includes(status)
      ) {
        badRows.push(idx + 1);
        return;
      }
      const key = `${subj}|${date}`;
      grouped[key] = grouped[key] || {};
      grouped[key][roll] = status;
    });

    return { grouped, badRows };
  }

  return {
    THRESHOLD,
    classifyTier,
    classesNeededForRecovery,
    buildIndex,
    computeStats,
    pearsonCorrelation,
    sanitizeCsvCell,
    parseCsvRows
  };
})();
