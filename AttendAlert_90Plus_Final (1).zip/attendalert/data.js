'use strict';

const SUBJECTS = [
  { id: 'DS', name: 'Data Structures' },
  { id: 'DBMS', name: 'DBMS' },
  { id: 'OS', name: 'Operating Systems' },
  { id: 'CN', name: 'Computer Networks' },
  { id: 'DM', name: 'Discrete Maths' }
];

const NAMES = [
  'Rahul Verma', 'Ananya Rao', 'Karthik Reddy', 'Meera Nair', 'Arjun Singh',
  'Sneha Iyer', 'Vikram Patel', 'Divya Menon', 'Rohan Gupta', 'Priya Sharma',
  'Aditya Kumar', 'Lakshmi Devi', 'Nikhil Jain', 'Pooja Bhat', 'Sanjay Das',
  'Isha Kapoor', 'Harsh Vardhan', 'Neha Joshi', 'Manoj Pillai', 'Kavya Reddy',
  'Siddharth Rao', 'Tanvi Shah', 'Varun Mehta', 'Aishwarya N', 'Deepak Yadav',
  'Ritika Sen', 'Abhishek Roy', 'Swathi K', 'Mohit Agarwal', 'Bhavana S'
];

function rng(s) {
  return () => (s = (s * 1664525 + 1013904223) % 4294967296) / 4294967296;
}

async function seed() {
  const r = rng(2026);
  const students = NAMES.map((n, i) => ({
    id: 'S' + String(i + 1).padStart(2, '0'),
    name: n,
    email: `s${String(i + 1).padStart(2, '0')}@college.edu`,
    parent: `parent${i + 1}@mail.com`,
    p: i < 5 ? 0.5 + r() * 0.1 : i < 10 ? 0.67 + r() * 0.07 : i < 14 ? 0.74 + r() * 0.03 : 0.82 + r() * 0.15
  }));

  const sessions = [];
  const now = new Date();
  let sid = 1;

  for (const sub of SUBJECTS) {
    for (let k = 0; k < 16; k++) {
      const d = new Date(now);
      d.setDate(now.getDate() - 27 + Math.floor(k / 4) * 7 + (k % 4) * 2);
      const marks = {};
      students.forEach((s, i) => {
        let ok = r() < Math.min(0.99, Math.max(0.3, s.p + (r() - 0.5) * 0.16));
        if (i === 0 && sub.id === 'DS') ok = k < 10; // Rahul = 10/16 = 62.5% -> needs 8 straight classes
        marks[s.id] = ok ? (r() < 0.08 ? 'L' : 'P') : 'A';
      });
      sessions.push({ id: sid++, subj: sub.id, date: d.toISOString().slice(0, 10), marks });
    }
  }

  const marks = {};
  students.forEach(s => {
    marks[s.id] = {};
    SUBJECTS.forEach(u => {
      const ss = sessions.filter(x => x.subj === u.id);
      const a = ss.filter(x => x.marks[s.id] !== 'A').length / ss.length;
      marks[s.id][u.id] = Math.round(Math.min(98, Math.max(18, 25 + a * 65 + (r() - 0.5) * 18)));
    });
  });

  const users = [
    { id: 'mentor', email: 'mentor@college.edu', role: 'mentor', name: 'Dr. Mentor', hash: await sha('mentor@123') }
  ];
  for (const s of students) {
    users.push({ id: s.id, email: s.email, role: 'student', name: s.name, hash: await sha('student@123') });
  }

  students.forEach(s => delete s.p);

  return {
    v: 3,
    students,
    sessions,
    marks,
    exempt: [],
    interventions: [],
    emails: [],
    auditLog: [],
    nextId: sid,
    users
  };
}
