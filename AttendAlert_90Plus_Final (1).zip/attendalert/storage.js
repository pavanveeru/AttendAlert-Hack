'use strict';

const STORAGE_KEY = 'attendalert.v2';
const DEFAULT_API_BASE = 'http://localhost:4000/api';

const StorageService = (() => {
  let apiOnline = false;

  function loadLocal() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }

  function saveLocal(db) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
      return { ok: true };
    } catch (err) {
      return { ok: false, error: err };
    }
  }

  function clearLocal() {
    localStorage.removeItem(STORAGE_KEY);
  }

  async function probeBackend(apiBase = DEFAULT_API_BASE) {
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 900);
      const res = await fetch(`${apiBase}/health`, { signal: ctrl.signal });
      clearTimeout(timer);
      apiOnline = res.ok;
      return apiOnline;
    } catch {
      apiOnline = false;
      return false;
    }
  }

  async function syncSnapshotToBackend(db, apiBase = DEFAULT_API_BASE) {
    if (!apiOnline) return false;
    try {
      const res = await fetch(`${apiBase}/sync`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(db)
      });
      return res.ok;
    } catch {
      return false;
    }
  }

  function isApiOnline() {
    return apiOnline;
  }

  return {
    loadLocal,
    saveLocal,
    clearLocal,
    probeBackend,
    syncSnapshotToBackend,
    isApiOnline
  };
})();
