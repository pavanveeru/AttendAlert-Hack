'use strict';

const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
}[c]));

const PAGE = 10;
let db, IDX = {}, ME = null, route = 'dash', F = { tier: 'all', q: '', page: 1, subj: 'ALL' };

const sname = id => SUBJECTS.find(s => s.id === id)?.name || id;
const stu = id => db.students.find(s => s.id === id);

function toast(m, t = '') {
  const e = document.createElement('div');
  e.className = 'toast ' + t;
  e.textContent = m;
  $('#toasts').append(e);
  setTimeout(() => e.remove(), 3500);
}

const safe = fn => (...a) => {
  try {
    return fn(...a);
  } catch (e) {
    console.error(e);
    toast('Action failed: ' + e.message, 'err');
  }
};

function audit(action, detail) {
  db.auditLog = db.auditLog || [];
  db.auditLog.push({
    at: new Date().toISOString(),
    actor: ME ? `${ME.id} (${ME.role})` : 'guest',
    action,
    detail
  });
  if (db.auditLog.length > 200) db.auditLog.shift();
}

function save() {
  const res = StorageService.saveLocal(db);
  if (!res.ok) {
    toast('Could not save — browser storage is full or blocked.', 'err');
    return;
  }
  if (StorageService.isApiOnline()) {
    StorageService.syncSnapshotToBackend(db);
  }
}

function reindex() {
  IDX = AttendanceAnalytics.buildIndex(db, SUBJECTS);
}

const tier = p => AttendanceAnalytics.classifyTier(p);
const need = (a, t) => AttendanceAnalytics.classesNeededForRecovery(a, t);
const st = (id, sub) => AttendanceAnalytics.computeStats(IDX, id, sub);
const badge = t => `<span class="badge ${t}">${t[0].toUpperCase() + t.slice(1)}</span>`;
const bar = p => `<div class="bar"><i style="width:${Math.min(100, Math.max(0, p))}%;background:${p >= 75 ? 'var(--p-amber)' : p >= 65 ? 'var(--p-coral)' : 'var(--p-rose)'}"></i></div>`;
const rows = () => db.students.map(s => ({ s, ...st(s.id, F.subj === 'ALL' ? null : F.subj) }));

function session() {
  return AuthService.getSession(db?.users || []);
}

const DEMO = {
  m: ['mentor@college.edu', 'mentor@123'],
  s: ['s01@college.edu', 'student@123']
};

document.querySelectorAll('[data-d]').forEach(b => {
  b.onclick = () => {
    [$('#uid').value, $('#pwd').value] = DEMO[b.dataset.d];
    $('#loginErr').textContent = '';
  };
});

$('#eye').onclick = () => {
  const p = $('#pwd');
  const h = p.type === 'password';
  p.type = h ? 'text' : 'password';
  $('#eye').textContent = h ? 'Hide' : 'Show';
};

$('#reset').onclick = () => {
  StorageService.clearLocal();
  AuthService.clearSession();
  location.reload();
};

$('#loginForm').onsubmit = async e => {
  e.preventDefault();
  const err = $('#loginErr');
  const em = $('#uid').value.trim().toLowerCase();
  const pw = $('#pwd').value;
  try {
    const res = await AuthService.authenticate(db?.users || [], em, pw);
    if (!res.ok) {
      err.textContent = res.message;
      return;
    }
    err.textContent = '';
    ME = res.user;
    audit('LOGIN', `Signed in as ${ME.email}`);
    save();
    boot();
  } catch (x) {
    console.error(x);
    err.textContent = 'Sign-in failed: ' + x.message + '. Click "Reset demo data" and try again.';
  }
};

$('#logout').onclick = () => {
  audit('LOGOUT', `Signed out ${ME?.id || ''}`);
  save();
  AuthService.clearSession();
  location.reload();
};

const NAV = {
  mentor: [
    ['dash', 'Dashboard'],
    ['mark', 'Mark attendance'],
    ['students', 'Students'],
    ['alerts', 'Alert hub'],
    ['medical', 'Medical leave'],
    ['insights', 'Insights'],
    ['import', 'CSV import'],
    ['report', 'Reports']
  ],
  student: [
    ['mine', 'My attendance']
  ]
};

const SUBTITLES = {
  dash: 'Early-warning risk summary, 75% threshold benchmarks & priority interventions',
  mark: 'Rapid session logging with Mark All Present toggle & instant shortage alerts',
  students: 'Filterable student roster, live percentages & consecutive recovery targets',
  alerts: 'Critical & warning shortage queue with one-click parent/student notifications',
  medical: 'Verified medical exemptions with immediate attendance recalculation',
  insights: 'Subject breakdown, weekly trends & Pearson attendance-to-marks correlation',
  import: 'Bulk biometric/roster CSV importer with strict schema & row validation',
  report: 'Exportable CSV & print-ready eligibility report with formula-injection protection',
  mine: 'Personal attendance summary, subject eligibility & recovery roadmap'
};

function boot() {
  const s = session();
  if (!s) {
    $('#login').hidden = false;
    $('#app').hidden = true;
    return;
  }
  ME = db.users.find(u => u.id === s.id);
  $('#login').hidden = true;
  $('#app').hidden = false;
  $('#who').textContent = `${ME.name} (${ME.role})`;
  $('#apiBadge').textContent = StorageService.isApiOnline()
    ? 'SQLite Backend: Connected'
    : 'Storage: LocalStore + SQL Sync';
  $('#today').textContent = new Date().toDateString();
  route = ME.role === 'student' ? 'mine' : 'dash';
  go(route);
}

function go(r) {
  if (!session()) return boot();
  if (!AuthService.isRouteAllowed(ME.role, r, NAV)) {
    r = NAV[ME.role][0][0];
  }
  route = r;
  F.page = 1;
  $('#nav').innerHTML = NAV[ME.role]
    .map(n => `<a data-r="${n[0]}" class="${n[0] === r ? 'on' : ''}" tabindex="0">${esc(n[1])}</a>`)
    .join('');
  $('#nav').querySelectorAll('a').forEach(a => {
    a.onclick = () => go(a.dataset.r);
    a.onkeydown = e => e.key === 'Enter' && go(a.dataset.r);
  });
  $('#title').textContent = NAV[ME.role].find(n => n[0] === r)[1];
  $('#subtitle').textContent = SUBTITLES[r] || '';
  render();
}

const render = safe(() => {
  if (!session()) return boot();
  $('#view').innerHTML = V[route]();
  (A[route] || (() => {}))();
});

function modal(h) {
  $('#mbody').innerHTML = h;
  $('#modal').hidden = false;
}
$('#mx').onclick = () => {
  $('#modal').hidden = true;
};

/* ---------- Charts (using #7C444F, #9F5255, #E16A54, #F39E60) ---------- */
function cv(sel) {
  const c = $(sel);
  const d = devicePixelRatio || 1;
  const w = Math.max(260, c.clientWidth || 600);
  const h = c.clientHeight || 280;
  c.width = w * d;
  c.height = h * d;
  const x = c.getContext('2d');
  x.scale(d, d);
  x.font = '12px Manrope, sans-serif';
  return { x, w, h };
}

function bars(sel, labels, vals) {
  const { x, w, h } = cv(sel);
  const bw = w / labels.length;
  const y75 = h - 30 - (h - 50) * 0.75;

  x.strokeStyle = '#E16A54';
  x.setLineDash([5, 4]);
  x.beginPath();
  x.moveTo(0, y75);
  x.lineTo(w, y75);
  x.stroke();
  x.setLineDash([]);

  vals.forEach((v, i) => {
    const bh = ((h - 50) * v) / 100;
    x.fillStyle = v >= 75 ? '#F39E60' : v >= 65 ? '#E16A54' : '#9F5255';
    x.fillRect(i * bw + bw * 0.22, h - 30 - bh, bw * 0.56, bh);
    x.fillStyle = '#FFF7F2';
    x.textAlign = 'center';
    x.fillText(v.toFixed(1) + '%', i * bw + bw / 2, h - 34 - bh);
    x.fillStyle = '#DFC3BA';
    x.fillText(labels[i], i * bw + bw / 2, h - 10);
  });
}

function scatter(sel, pts) {
  const { x, w, h } = cv(sel);
  const m = 38;
  x.strokeStyle = 'rgba(243, 158, 96, 0.2)';
  x.fillStyle = '#DFC3BA';

  [0, 25, 50, 75, 100].forEach(v => {
    const X = m + ((w - m - 12) * v) / 100;
    const Y = h - m - ((h - m - 12) * v) / 100;
    x.beginPath();
    x.moveTo(X, 10);
    x.lineTo(X, h - m);
    x.moveTo(m, Y);
    x.lineTo(w - 12, Y);
    x.stroke();
    x.textAlign = 'center';
    x.fillText(v, X, h - m + 16);
    x.textAlign = 'right';
    x.fillText(v, m - 6, Y + 4);
  });

  pts.forEach(p => {
    x.fillStyle = p.t === 'safe' ? '#F39E60' : p.t === 'warning' ? '#E16A54' : '#9F5255';
    x.beginPath();
    x.arc(m + ((w - m - 12) * p.x) / 100, h - m - ((h - m - 12) * p.y) / 100, 5, 0, Math.PI * 2);
    x.fill();
  });

  x.fillStyle = '#DFC3BA';
  x.textAlign = 'center';
  x.fillText('Attendance % ->   (vertical: midterm marks)', w / 2, h - 4);
}

function line(sel, vals, labels) {
  const { x, w, h } = cv(sel);
  const m = 36;
  x.strokeStyle = '#F39E60';
  x.lineWidth = 2.5;
  x.beginPath();
  vals.forEach((v, i) => {
    const X = m + ((w - m - 16) * i) / Math.max(1, vals.length - 1);
    const Y = h - m - ((h - m - 14) * v) / 100;
    i ? x.lineTo(X, Y) : x.moveTo(X, Y);
  });
  x.stroke();

  vals.forEach((v, i) => {
    const X = m + ((w - m - 16) * i) / Math.max(1, vals.length - 1);
    const Y = h - m - ((h - m - 14) * v) / 100;
    x.fillStyle = '#E16A54';
    x.beginPath();
    x.arc(X, Y, 4.5, 0, Math.PI * 2);
    x.fill();
    x.fillStyle = '#DFC3BA';
    x.textAlign = 'center';
    x.fillText(labels[i], X, h - 10);
    x.fillText(v.toFixed(1) + '%', X, Y - 9);
  });
}

/* ---------- Views ---------- */
const subjSel = (id, all) => `<select id="${id}">${all ? '<option value="ALL">All subjects</option>' : ''}${SUBJECTS.map(s => `<option value="${s.id}" ${F.subj === s.id ? 'selected' : ''}>${esc(s.name)}</option>`).join('')}</select>`;

const V = {
  dash() {
    const R = rows();
    const c = R.filter(r => r.tier === 'critical');
    const w = R.filter(r => r.tier === 'warning');
    const avg = R.reduce((a, r) => a + r.p, 0) / Math.max(1, R.length);
    return `
      ${c.length ? `<div class="banner"><span>${c.length} students in critical shortage (&lt;65%)</span><button class="btn ghost sm" onclick="go('alerts')">Open alert hub</button></div>` : ''}
      <div class="grid">
        <div class="card kpi"><b>${R.length}</b><span>Students tracked</span></div>
        <div class="card kpi"><b>${avg.toFixed(1)}%</b><span>Department average</span></div>
        <div class="card kpi"><b style="color:var(--p-coral)">${w.length}</b><span>Warning (65-74%)</span></div>
        <div class="card kpi"><b style="color:var(--p-rose)">${c.length}</b><span>Critical (&lt;65%)</span></div>
      </div>
      <div class="card">
        <h3>Subject-wise department average</h3>
        <canvas id="c1"></canvas>
        <p class="note">Dashed line marks the 75% eligibility threshold.</p>
      </div>
      <div class="spacer"></div>
      <div class="card">
        <h3>Lowest attendance right now</h3>
        <table>
          <tr><th>Student</th><th>Overall</th><th>Tier</th><th>Classes to recover</th></tr>
          ${R.sort((a, b) => a.p - b.p).slice(0, 6).map(r => `
            <tr class="click" onclick="detail('${r.s.id}')">
              <td>${esc(r.s.name)}</td>
              <td>${r.p.toFixed(1)}%</td>
              <td>${badge(r.tier)}</td>
              <td>${r.need}</td>
            </tr>
          `).join('')}
        </table>
      </div>`;
  },

  students() {
    const R = rows()
      .filter(r => (F.tier === 'all' || r.tier === F.tier) && r.s.name.toLowerCase().includes(F.q.toLowerCase()))
      .sort((a, b) => a.p - b.p);
    const n = Math.max(1, Math.ceil(R.length / PAGE));
    F.page = Math.min(F.page, n);
    return `
      <div class="card">
        <div class="row">
          <label>Search<input id="q" value="${esc(F.q)}" placeholder="Name"></label>
          <label>Subject${subjSel('fs', 1)}</label>
          <label>Risk tier<select id="ft">${['all', 'safe', 'warning', 'critical'].map(t => `<option ${F.tier === t ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
        </div>
        <table>
          <tr><th>Roll</th><th>Name</th><th>Attended / Held</th><th>%</th><th></th><th>Tier</th><th>Recover in</th></tr>
          ${R.slice((F.page - 1) * PAGE, F.page * PAGE).map(r => `
            <tr class="click" onclick="detail('${r.s.id}')">
              <td>${esc(r.s.id)}</td>
              <td>${esc(r.s.name)}</td>
              <td>${r.a}/${r.t}</td>
              <td>${r.p.toFixed(1)}%</td>
              <td>${bar(r.p)}</td>
              <td>${badge(r.tier)}</td>
              <td>${r.need ? r.need + ' classes' : '-'}</td>
            </tr>
          `).join('') || '<tr><td colspan="7">No students match these filters.</td></tr>'}
        </table>
        <div class="pager">
          <button class="btn ghost sm" id="pp">Prev</button>
          Page ${F.page} of ${n}
          <button class="btn ghost sm" id="pn">Next</button>
        </div>
      </div>`;
  },

  mark() {
    const today = new Date().toISOString().slice(0, 10);
    return `
      <div class="card">
        <div class="row">
          <label>Subject${subjSel('ms')}</label>
          <label>Date<input type="date" id="md" value="${today}" max="${today}"></label>
          <button class="btn ghost" id="allP">Mark all present</button>
          <button class="btn" id="saveA">Save attendance</button>
        </div>
        <table id="mt">
          <tr><th>Roll</th><th>Name</th><th>Status</th></tr>
          ${db.students.map(s => `
            <tr data-id="${s.id}">
              <td>${esc(s.id)}</td>
              <td>${esc(s.name)}</td>
              <td>
                <div class="seg">
                  ${['P', 'A', 'L'].map(k => `<button type="button" data-k="${k}" class="${k === 'P' ? 'on ' : ''}${k}">${{ P: 'Present', A: 'Absent', L: 'Late' }[k]}</button>`).join('')}
                </div>
              </td>
            </tr>
          `).join('')}
        </table>
        <p class="note">Everyone starts as present — just tap the absent and late ones. Late counts as attended.</p>
      </div>`;
  },

  alerts() {
    const L = [];
    db.students.forEach(s => SUBJECTS.forEach(u => {
      const x = st(s.id, u.id);
      if (x.tier !== 'safe') L.push({ s, u, ...x });
    }));
    L.sort((a, b) => a.p - b.p);
    return `
      <div class="card">
        <div class="row">
          <h3 style="flex:2">${L.length} at-risk subject records</h3>
          <button class="btn" id="mailAll">Email all critical students</button>
        </div>
        <table>
          <tr><th>Student</th><th>Subject</th><th>%</th><th>Tier</th><th>Must attend</th><th></th></tr>
          ${L.map(r => `
            <tr>
              <td>${esc(r.s.name)}</td>
              <td>${esc(r.u.name)}</td>
              <td>${r.p.toFixed(1)}%</td>
              <td>${badge(r.tier)}</td>
              <td>${r.need} in a row</td>
              <td><button class="btn ghost sm" onclick="detail('${r.s.id}')">Mentor</button></td>
            </tr>
          `).join('')}
        </table>
      </div>
      <div class="spacer"></div>
      <div class="card">
        <h3>Simulated email outbox (${db.emails.length})</h3>
        ${db.emails.slice(-8).reverse().map(m => `<p class="note">${esc(m.at)} -> ${esc(m.to)}: ${esc(m.sub)}</p>`).join('') || '<p class="note">No emails sent yet.</p>'}
      </div>`;
  },

  medical() {
    return `
      <div class="card">
        <h3>Approve a medical exemption</h3>
        <div class="row">
          <label>Student<select id="es">${db.students.map(s => `<option value="${s.id}">${s.id} - ${esc(s.name)}</option>`).join('')}</select></label>
          <label>Subject${subjSel('eu')}</label>
          <label>Days excused<input type="number" id="en" min="1" max="10" value="2"></label>
          <label>Certificate<input type="file" id="ef" accept=".pdf,.jpg,.png"></label>
          <button class="btn" id="eb">Approve &amp; recalculate</button>
        </div>
        <h3>Approved exemptions</h3>
        <table>
          <tr><th>Student</th><th>Subject</th><th>Days</th><th>Certificate</th></tr>
          ${db.exempt.map(e => `<tr><td>${esc(e.sid)}</td><td>${esc(sname(e.subj))}</td><td>${esc(e.n)}</td><td>${esc(e.file)}</td></tr>`).join('') || '<tr><td colspan="4">None yet.</td></tr>'}
        </table>
      </div>`;
  },

  insights() {
    const sub = F.subj === 'ALL' ? 'DS' : F.subj;
    const pts = db.students.map(s => ({ x: st(s.id, sub).p, y: db.marks[s.id][sub], t: st(s.id, sub).tier }));
    const r = AttendanceAnalytics.pearsonCorrelation(pts);
    return `
      <div class="card">
        <h3>Department analytics by subject</h3>
        <table>
          <tr><th>Subject</th><th>Average</th><th>Safe</th><th>Warning</th><th>Critical</th></tr>
          ${SUBJECTS.map(u => {
            const t = db.students.map(s => st(s.id, u.id));
            return `<tr><td>${esc(u.name)}</td><td>${(t.reduce((a, x) => a + x.p, 0) / t.length).toFixed(1)}%</td><td>${t.filter(x => x.tier === 'safe').length}</td><td>${t.filter(x => x.tier === 'warning').length}</td><td>${t.filter(x => x.tier === 'critical').length}</td></tr>`;
          }).join('')}
        </table>
      </div>
      <div class="spacer"></div>
      <div class="card">
        <h3>Weekly attendance trend</h3>
        <canvas id="c2"></canvas>
      </div>
      <div class="spacer"></div>
      <div class="card">
        <div class="row"><h3 style="flex:2">Attendance vs midterm marks</h3>${subjSel('is')}</div>
        <canvas id="c3"></canvas>
        <p class="note">Pearson correlation r = <b>${r.toFixed(2)}</b> — ${Math.abs(r) > 0.6 ? 'strong' : 'moderate'} ${r > 0 ? 'positive' : 'negative'} relationship in ${esc(sname(sub))}.</p>
      </div>`;
  },

  import() {
    return `
      <div class="card">
        <h3>Import attendance from CSV</h3>
        <p class="note">Columns: <code>roll,subject,date,status</code> — subject is DS, DBMS, OS, CN or DM; status is P, A or L. Rows are validated and bad rows are reported.</p>
        <br>
        <input type="file" id="csv" accept=".csv,text/csv">
        <div id="csvOut" class="note" style="margin-top:12px"></div>
      </div>`;
  },

  report() {
    const R = rows().sort((a, b) => a.p - b.p);
    return `
      <div class="card">
        <div class="row">
          <h3 style="flex:2">Attendance report — ${esc(new Date().toDateString())}</h3>
          <button class="btn" id="dl">Download CSV</button>
          <button class="btn ghost" onclick="print()">Save as PDF</button>
        </div>
        <table>
          <tr><th>Roll</th><th>Name</th>${SUBJECTS.map(u => `<th>${u.id}</th>`).join('')}<th>Overall</th><th>Tier</th></tr>
          ${R.map(r => `
            <tr>
              <td>${esc(r.s.id)}</td>
              <td>${esc(r.s.name)}</td>
              ${SUBJECTS.map(u => `<td>${st(r.s.id, u.id).p.toFixed(0)}%</td>`).join('')}
              <td>${r.p.toFixed(1)}%</td>
              <td>${badge(r.tier)}</td>
            </tr>
          `).join('')}
        </table>
      </div>`;
  },

  mine() {
    const s = stu(ME.id);
    const o = st(s.id);
    return `
      ${o.tier !== 'safe' ? `<div class="banner"><span>Your overall attendance is ${o.p.toFixed(1)}% — ${o.tier === 'critical' ? 'below the 65% critical line' : 'under the 75% requirement'}.</span></div>` : ''}
      <div class="grid">
        <div class="card kpi"><b>${o.p.toFixed(1)}%</b><span>Overall · ${badge(o.tier)}</span></div>
        <div class="card kpi"><b>${o.a}/${o.t}</b><span>Classes attended</span></div>
      </div>
      <div class="card">
        <h3>By subject</h3>
        <table>
          <tr><th>Subject</th><th>Attended</th><th>%</th><th></th><th>Status</th><th>Next steps</th></tr>
          ${SUBJECTS.map(u => {
            const x = st(s.id, u.id);
            return `<tr><td>${esc(u.name)}</td><td>${x.a}/${x.t}</td><td>${x.p.toFixed(1)}%</td><td>${bar(x.p)}</td><td>${badge(x.tier)}</td><td>${x.need ? `Attend next ${x.need} classes in a row` : 'You are eligible'}</td></tr>`;
          }).join('')}
        </table>
      </div>`;
  }
};

function mail(s, why) {
  db.emails.push({ at: new Date().toLocaleString(), to: `${s.email}, ${s.parent}`, sub: why });
}

window.go = go;

window.detail = safe(id => {
  if (!ME || ME.role !== 'mentor') return;
  const s = stu(id);
  if (!s) return;
  modal(`
    <h2>${esc(s.name)} <small class="note">${esc(s.id)}</small></h2>
    <table>
      <tr><th>Subject</th><th>%</th><th>Tier</th><th>Must attend</th></tr>
      ${SUBJECTS.map(u => {
        const x = st(id, u.id);
        return `<tr><td>${esc(u.name)}</td><td>${x.p.toFixed(1)}%</td><td>${badge(x.tier)}</td><td>${x.need ? x.need + ' consecutive classes' : '-'}</td></tr>`;
      }).join('')}
    </table>
    <h3 style="margin-top:16px">Log mentoring intervention</h3>
    <textarea id="note" rows="3" maxlength="500" placeholder="Counselling notes, agreed actions..."></textarea>
    <br><br>
    <button class="btn" id="logN">Log mentoring intervention</button>
    ${(db.interventions || []).filter(i => i.sid === id).map(i => `<p class="note">${esc(i.at)} — ${esc(i.note)}</p>`).join('')}
  `);
  $('#logN').onclick = safe(() => {
    const t = $('#note').value.trim();
    if (!t) return toast('Write a short note first.', 'err');
    db.interventions.push({ sid: id, note: t, at: new Date().toLocaleString() });
    audit('INTERVENTION', `Logged note for ${id}`);
    save();
    toast('Intervention logged');
    detail(id);
  });
});

const A = {
  dash() {
    bars(
      '#c1',
      SUBJECTS.map(u => u.id),
      SUBJECTS.map(u => db.students.reduce((a, s) => a + st(s.id, u.id).p, 0) / Math.max(1, db.students.length))
    );
  },

  students() {
    const re = safe(() => {
      $('#view').innerHTML = V.students();
      A.students();
    });
    $('#q').oninput = e => {
      F.q = e.target.value;
      F.page = 1;
      re();
      const qEl = $('#q');
      qEl.focus();
      qEl.setSelectionRange(qEl.value.length, qEl.value.length);
    };
    $('#fs').onchange = e => {
      F.subj = e.target.value;
      F.page = 1;
      re();
    };
    $('#ft').onchange = e => {
      F.tier = e.target.value;
      F.page = 1;
      re();
    };
    $('#pp').onclick = () => {
      F.page = Math.max(1, F.page - 1);
      re();
    };
    $('#pn').onclick = () => {
      F.page += 1;
      re();
    };
  },

  mark() {
    $('#mt').onclick = e => {
      const b = e.target.closest('button');
      if (!b) return;
      b.parentElement.querySelectorAll('button').forEach(x => x.classList.remove('on'));
      b.classList.add('on');
    };
    $('#allP').onclick = () => {
      $('#mt').querySelectorAll('.seg').forEach(g => {
        g.querySelectorAll('button').forEach(x => x.classList.toggle('on', x.dataset.k === 'P'));
      });
    };
    $('#saveA').onclick = safe(() => {
      const subj = $('#ms').value;
      const date = $('#md').value;
      if (!date) return toast('Pick a date.', 'err');
      if (db.sessions.some(x => x.subj === subj && x.date === date)) {
        return toast('Attendance for this subject and date already exists.', 'err');
      }
      const marks = {};
      $('#mt').querySelectorAll('tr[data-id]').forEach(tr => {
        marks[tr.dataset.id] = tr.querySelector('.on').dataset.k;
      });
      db.sessions.push({ id: db.nextId++, subj, date, marks });
      reindex();
      const crit = db.students.filter(s => st(s.id, subj).tier === 'critical' && marks[s.id] === 'A');
      crit.forEach(s => mail(s, `Critical attendance shortage in ${sname(subj)}`));
      audit('ATTENDANCE_SAVED', `${subj} on ${date} (${crit.length} critical alerts)`);
      save();
      toast(crit.length ? `Saved. ${crit.length} absent student(s) are now critical — alert emails queued.` : 'Attendance saved.');
    });
  },

  alerts() {
    $('#mailAll').onclick = safe(() => {
      const c = db.students.filter(s => st(s.id).tier === 'critical');
      c.forEach(s => mail(s, `Critical attendance warning: ${st(s.id).p.toFixed(1)}% overall`));
      audit('BULK_ALERT', `Sent ${c.length} critical warning emails`);
      save();
      toast(`${c.length} warning emails simulated.`);
      render();
    });
  },

  medical() {
    $('#eb').onclick = safe(() => {
      const f = $('#ef').files[0];
      if (!f) return toast('Attach a medical certificate first.', 'err');
      const n = +$('#en').value;
      if (!(n >= 1 && n <= 10)) return toast('Days must be 1-10.', 'err');
      db.exempt.push({ sid: $('#es').value, subj: $('#eu').value, n, file: f.name });
      reindex();
      audit('MEDICAL_EXEMPTION', `${$('#es').value} +${n} days in ${$('#eu').value}`);
      save();
      toast('Exemption approved — percentages recalculated.');
      render();
    });
  },

  insights() {
    const sub = F.subj === 'ALL' ? 'DS' : F.subj;
    $('#is').onchange = e => {
      F.subj = e.target.value;
      render();
    };
    const ds = [...new Set(db.sessions.map(x => x.date))].sort();
    const wk = [0, 1, 2, 3].map(w => {
      const ss = db.sessions.filter(x => ds.indexOf(x.date) >= (w * ds.length) / 4 && ds.indexOf(x.date) < ((w + 1) * ds.length) / 4);
      let a = 0, t = 0;
      ss.forEach(x => Object.values(x.marks).forEach(m => {
        t += 1;
        if (m !== 'A') a += 1;
      }));
      return t ? (a / t) * 100 : 0;
    });
    line('#c2', wk, ['Week 1', 'Week 2', 'Week 3', 'Week 4']);
    scatter('#c3', db.students.map(s => ({ x: st(s.id, sub).p, y: db.marks[s.id][sub], t: st(s.id, sub).tier })));
  },

  import() {
    $('#csv').onchange = safe(e => {
      const f = e.target.files[0];
      if (!f) return;
      if (f.size > 2e6) return toast('File too large (2 MB max).', 'err');
      const rd = new FileReader();
      rd.onerror = () => toast('Could not read that file.', 'err');
      rd.onload = safe(() => {
        const { grouped, badRows } = AttendanceAnalytics.parseCsvRows(rd.result, db.students, SUBJECTS);
        let importedSessions = 0;
        for (const k in grouped) {
          const [subj, date] = k.split('|');
          if (db.sessions.some(x => x.subj === subj && x.date === date)) continue;
          const marks = {};
          db.students.forEach(s => {
            marks[s.id] = grouped[k][s.id] || 'A';
          });
          db.sessions.push({ id: db.nextId++, subj, date, marks });
          importedSessions += 1;
        }
        reindex();
        audit('CSV_IMPORT', `Imported ${importedSessions} sessions, skipped ${badRows.length} rows`);
        save();
        $('#csvOut').innerHTML = `Imported ${importedSessions} class session(s). ${badRows.length ? `<span style="color:var(--p-coral)">Skipped invalid rows: ${badRows.slice(0, 15).join(', ')}</span>` : 'No invalid rows.'}`;
      });
      rd.readAsText(f);
    });
  },

  report() {
    $('#dl').onclick = safe(() => {
      const R = rows().sort((a, b) => a.p - b.p);
      const q = AttendanceAnalytics.sanitizeCsvCell;
      const csv = [
        ['Roll', 'Name', ...SUBJECTS.map(u => u.id), 'Overall %', 'Tier'].join(','),
        ...R.map(r => [r.s.id, q(r.s.name), ...SUBJECTS.map(u => st(r.s.id, u.id).p.toFixed(1)), r.p.toFixed(1), r.tier].join(','))
      ].join('\n');
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
      a.download = 'attendance-report.csv';
      a.click();
      audit('REPORT_EXPORTED', 'Downloaded attendance-report.csv');
      save();
      toast('Report downloaded.');
    });
  }
};

(async () => {
  try {
    await StorageService.probeBackend();
    $('#backendStatus').textContent = StorageService.isApiOnline() ? 'SQLite API Live' : 'Local / SQL-Ready';
    $('#backendStatus').classList.toggle('online', StorageService.isApiOnline());

    db = StorageService.loadLocal();
    if (!db || db.v !== 3) {
      db = await seed();
      save();
    }
    reindex();
    $('#loginBtn').disabled = false;
    boot();
    addEventListener('resize', safe(() => {
      if (session() && ['dash', 'insights'].includes(route)) render();
    }));
  } catch (e) {
    console.error(e);
    $('#loginErr').textContent = 'Could not load data: ' + e.message + '. Click "Reset demo data".';
    $('#loginBtn').disabled = false;
  }
})();
