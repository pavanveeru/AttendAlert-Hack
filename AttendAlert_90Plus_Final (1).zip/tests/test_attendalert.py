import json
import math
import re
import sqlite3
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def classify_tier(pct: float) -> str:
    if pct >= 75.0:
        return "safe"
    if pct >= 65.0:
        return "warning"
    return "critical"


def classes_needed_for_recovery(attended: int, total: int, threshold: float = 0.75) -> int:
    if total <= 0:
        return 0
    pct = (attended / total) * 100.0
    if pct >= threshold * 100.0:
        return 0
    return max(0, math.ceil((threshold * total - attended) / (1.0 - threshold)))


def sanitize_csv_cell(val: str) -> str:
    s = str(val if val is not None else "")
    if re.match(r"^[=+\-@]", s):
        s = "'" + s
    return '"' + s.replace('"', '""') + '"'


class TestAttendAlertSuite(unittest.TestCase):
    def test_recovery_formula_rahul_case(self):
        # Rahul Verma has 10/16 = 62.5% -> needs 8 consecutive classes to hit 18/24 = 75.0%
        needed = classes_needed_for_recovery(10, 16)
        self.assertEqual(needed, 8)
        self.assertAlmostEqual((10 + needed) / (16 + needed), 0.75)

    def test_risk_tiers_and_boundaries(self):
        self.assertEqual(classify_tier(75.0), "safe")
        self.assertEqual(classify_tier(92.4), "safe")
        self.assertEqual(classify_tier(74.9), "warning")
        self.assertEqual(classify_tier(65.0), "warning")
        self.assertEqual(classify_tier(64.9), "critical")
        self.assertEqual(classify_tier(40.0), "critical")

    def test_zero_classes_or_already_eligible(self):
        self.assertEqual(classes_needed_for_recovery(0, 0), 0)
        self.assertEqual(classes_needed_for_recovery(12, 16), 0)
        self.assertEqual(classes_needed_for_recovery(15, 16), 0)

    def test_csv_formula_injection_prevention(self):
        self.assertEqual(sanitize_csv_cell("=SUM(A1:A5)"), `"'=SUM(A1:A5)"`)
        self.assertEqual(sanitize_csv_cell("+cmd|'/C calc'!A0"), `'"+cmd|'/C calc'!A0"`)
        self.assertEqual(sanitize_csv_cell("Ananya Rao"), '"Ananya Rao"')

    def test_real_sqlite_file_persistence_and_exemption_math(self):
        schema_sql = (ROOT / "backend" / "schema.sql").read_text(encoding="utf-8")
        seed_sql = (ROOT / "backend" / "seed.sql").read_text(encoding="utf-8")

        with tempfile.TemporaryDirectory() as tmpdir:
            db_file = Path(tmpdir) / "attendalert.sqlite"
            conn = sqlite3.connect(db_file)
            conn.executescript(schema_sql)
            conn.executescript(seed_sql)

            conn.execute(
                "INSERT INTO students (id, name, email, parent_email) VALUES (?, ?, ?, ?)",
                ("S01", "Rahul Verma", "s01@college.edu", "p1@mail.com"),
            )
            for k in range(1, 17):
                status = "P" if k <= 10 else "A"
                conn.execute(
                    "INSERT INTO attendance_sessions (id, subj_id, session_date) VALUES (?, ?, ?)",
                    (k, "DS", f"2026-10-{k:02d}"),
                )
                conn.execute(
                    "INSERT INTO attendance_records (session_id, student_id, status) VALUES (?, ?, ?)",
                    (k, "S01", status),
                )

            row = conn.execute(
                "SELECT COUNT(*) AS held, SUM(CASE WHEN status != 'A' THEN 1 ELSE 0 END) AS att FROM attendance_records WHERE student_id='S01'"
            ).fetchone()
            self.assertEqual(row, (16, 10))
            self.assertEqual(classes_needed_for_recovery(row[1], row[0]), 8)

            # Approve 2-day medical exemption -> 12/16 = 75.0% -> Safe, 0 classes needed
            conn.execute(
                "INSERT INTO exemptions (student_id, subj_id, days_excused, certificate_name) VALUES (?, ?, ?, ?)",
                ("S01", "DS", 2, "med_cert.pdf"),
            )
            excused = conn.execute(
                "SELECT COALESCE(SUM(days_excused), 0) FROM exemptions WHERE student_id='S01' AND subj_id='DS'"
            ).fetchone()[0]
            new_att = min(row[0], row[1] + excused)
            new_pct = (new_att / row[0]) * 100.0
            self.assertEqual(classify_tier(new_pct), "safe")
            self.assertEqual(classes_needed_for_recovery(new_att, row[0]), 0)
            conn.close()

    def test_observability_openapi_and_cicd_artifacts_exist(self):
        self.assertTrue((ROOT / "backend" / "db.js").exists())
        self.assertTrue((ROOT / "backend" / "middleware.js").exists())
        self.assertTrue((ROOT / "backend" / "openapi.js").exists())
        self.assertTrue((ROOT / ".github" / "workflows" / "ci.yml").exists())

        middleware_src = (ROOT / "backend" / "middleware.js").read_text(encoding="utf-8")
        self.assertIn("withErrorBoundary", middleware_src)
        self.assertIn("logStructured", middleware_src)
        self.assertIn("validateSessionPayload", middleware_src)

    def test_palette_tokens_present_in_css_and_react(self):
        css = (ROOT / "attendalert" / "styles.css").read_text(encoding="utf-8").upper()
        react_app = (ROOT / "react-ts-phase" / "src" / "App.tsx").read_text(encoding="utf-8").upper()
        for hex_code in ["#7C444F", "#9F5255", "#E16A54", "#F39E60"]:
            self.assertIn(hex_code, css)
            self.assertIn(hex_code, react_app)


if __name__ == "__main__":
    unittest.main()
